package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class MainPerformance {

    @FXML
    private Label result;

    private float number1 = 0;
    private float number2;
    private boolean start = true;
    private String operator = "";
    private Calculation model = new Calculation();

    @FXML
    public void processOperators(ActionEvent event) {
        String value = ((Button) event.getSource()).getText();

        if (value.equals("C")) {
            result.setText("");
            number1 = 0;
            number2 = 0;
            operator = "";
            start = true;
            return;
        }

        if (!value.equals("=")) {
            if (!operator.isEmpty()) {
                return;
            }
            operator = value;
            number1 = Float.parseFloat(result.getText());
            result.setText("");
        } else {
            if (operator.isEmpty()) {
                return;
            }
            number2 = Float.parseFloat(result.getText());
            try {
                float output = model.calculate(number1, number2, operator);
                result.setText(String.valueOf(output));
            } catch (IllegalArgumentException e) {
                result.setText("Error: " + e.getMessage());
            }
            operator = "";
            start = true;
        }
    }

    @FXML
    public void processNumbers(ActionEvent event) {
        String value = ((Button) event.getSource()).getText();
        if (start) {
            result.setText("");
            start = false;
        }
        result.setText(result.getText() + value);
    }
}
