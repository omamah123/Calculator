package application;

public class Calculation {
    
    public float calculate(float n1, float n2, String op) {
        switch (op) {
            case "+":
                return n1 + n2;
            case "-":
                return n1 - n2;
            case "*":
                return n1 * n2;
            case "/":
                if (n2 != 0) 
                    return n1 / n2;
                else
                    throw new IllegalArgumentException("Division by zero is not allowed.");
            default:
                throw new IllegalArgumentException("Unsupported operation: " + op);
        }
    }
}
